(function() {
    'use strict';
    var gotoTop = document.createElement("div");
    document.body.appendChild(gotoTop);
    gotoTop.id="back_to_top";
    gotoTop.style.width = '40px';
    gotoTop.style.height = '40px';
    gotoTop.style.position = 'fixed';
    gotoTop.style.bottom = '40px';
    gotoTop.style.right = '0px';
    gotoTop.style.borderRadius = '3px 3px 3px 3px';
    gotoTop.style.textDecoration = 'none';
    gotoTop.style.textAlign = 'center';
    gotoTop.style.display = 'none';
    gotoTop.style.backgroundColor = '#B3B3B3';
    gotoTop.style.cursor = 'pointer';
    gotoTop.innerHTML = '<div id="bttd" style="display:block;font-size:13px;font-family: Tahoma;color:#fff;line-height:17px;width:37px;padding-top: 3px;"title="top">top</div>';

    $('#back_to_top').click(function(event) {
        event.preventDefault();
        $('html, body').animate({scrollTop: 0}, 200);
    });

})();