export default {
    isAuthenticated: false,  //授权
    user: {},  //用户登录
};