module.exports = {
  mongoURI: "mongodb://test:Z123456@ds135233.mlab.com:35233/restful-api-vue",
  secretOrKey: "secret"
};